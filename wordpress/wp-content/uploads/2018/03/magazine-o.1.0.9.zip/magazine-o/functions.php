<?php
/**
 * Magazine O functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Magazine_O
 */

if ( ! function_exists( 'magazine_o_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function magazine_o_setup() {

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );
		// Thumbnail sizes
		add_image_size( 'magazine-o-thumbnail-1', 565, 440, true );
		add_image_size( 'magazine-o-thumbnail-2', 570, 225, true );
		add_image_size( 'magazine-o-thumbnail-3', 283, 210, true );
		add_image_size( 'magazine-o-thumbnail-4', 360, 240, true );
		add_image_size( 'magazine-o-thumbnail-5', 100, 75, true );
		add_image_size( 'magazine-o-thumbnail-6', 240, 280, true );
		add_image_size( 'magazine-o-thumbnail-7', 172, 120, true );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'top_menu' => esc_html__( 'Top Menu', 'magazine-o' ),
			'primary_menu' => esc_html__( 'Primary Menu', 'magazine-o' ),
			'footer_menu' => esc_html__( 'Footer Menu', 'magazine-o' ),
		) );

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'magazine_o_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 90,
			'width'       => 360,
			'flex-width'  => true,
			'flex-height' => true,
		) );
	}
endif;
add_action( 'after_setup_theme', 'magazine_o_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function magazine_o_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'magazine_o_content_width', 640 );
}
add_action( 'after_setup_theme', 'magazine_o_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function magazine_o_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'magazine-o' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'magazine-o' ),
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside>',
		'before_title'  => '<div class="widget-title"><h3>',
		'after_title'   => '</h3></div>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Featured Posts Widget Area', 'magazine-o' ),
		'id'            => 'sidebar-2',
		'description'   => esc_html__( 'Add Featured Post Widget Here.', 'magazine-o' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Front Page Widget Area Top', 'magazine-o' ),
		'id'            => 'sidebar-3',
		'description'   => esc_html__( 'Add News Layout Widgets Here.', 'magazine-o' ),
		'before_widget' => '<div id="%1$s" class="block %2$s">',
		'after_widget'  => '</div>',
		'before_title'  => '<div class="block-title">',
		'after_title'   => '</div>',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Front Page Widget Area Bottom', 'magazine-o' ),
		'id'            => 'sidebar-4',
		'description'   => esc_html__( 'Add News Layout Widgets Here.', 'magazine-o' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '',
		'after_title'   => '',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Header Advertisement Widget Area', 'magazine-o' ),
		'id'            => 'sidebar-5',
		'description'   => esc_html__( 'Add 729x90 Advertisement Here.', 'magazine-o' ),
		'before_widget' => '',
		'after_widget'  => '',
		'before_title'  => '',
		'after_title'   => '',
	) );

	register_sidebar( array(
		'name'          => esc_html__( 'Footer', 'magazine-o' ),
		'id'            => 'footer-1',
		'description'   => esc_html__( 'Add Widgets Here.', 'magazine-o' ),
		'before_widget' => '<div class="col-sm-4 col-xs-12"><aside id="%1$s" class="widget %2$s">',
		'after_widget'  => '</aside></div>',
		'before_title'  => '<div class="widget-title"><h3>',
		'after_title'   => '</h3></div>',
	) );
}
add_action( 'widgets_init', 'magazine_o_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function magazine_o_scripts() {
	wp_enqueue_style( 'magazine-o-style', get_stylesheet_uri() );
	// Bootstrap
	wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/ocean-themes/assets/css/bootstrap.min.css' );
	// Font Awesome
	wp_enqueue_style( 'font-awesome', get_template_directory_uri() . '/ocean-themes/assets/css/font-awesome.min.css' );
	// Google Font
	wp_enqueue_style( 'magazine-o-fonts', magazine_o_google_fonts() );
	// Custom
	wp_enqueue_style( 'magazine-o-custom', get_template_directory_uri() . '/ocean-themes/assets/css/custom.css' );
	// Color
	wp_enqueue_style( 'magazine-o-color', get_template_directory_uri() . '/ocean-themes/assets/css/color.css' );
	// Responsive
	wp_enqueue_style( 'magazine-o-responsive', get_template_directory_uri() . '/ocean-themes/assets/css/responsive.css' );
	// Print Style
	wp_enqueue_style( 'magazine-o-print', get_template_directory_uri() . '/ocean-themes/assets/css/print.css' );

	// JS
	wp_enqueue_script( 'magazine-o-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20151215', true );
	// Bootstrap JS
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/ocean-themes/assets/js/bootstrap.min.js', array('jquery'), '20151215', true );
	// Owl Carousel
	wp_enqueue_script( 'owl', get_template_directory_uri() . '/ocean-themes/assets/js/owl.carousel.min.js', array('jquery'), '20151215', true );

	// Custom JS
	wp_enqueue_script( 'magazine-o-custom', get_template_directory_uri() . '/ocean-themes/assets/js/custom.js', array('custom'), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'magazine_o_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Widgets
 */
require get_template_directory() . '/ocean-themes/widgets-init.php';

/**
 * Helper Functions
 */
require get_template_directory() . '/ocean-themes/helpers.php';


/**
 * Load Bootstrap Navwalker
 */
require get_template_directory() . '/ocean-themes/third-party/wp-bootstrap-navwalker.php';

/**
 * Load Breadcrumb
 */
require get_template_directory() . '/ocean-themes/third-party/breadcrumbs.php';
/**
 * One Click Demo
 */

if ( is_admin() ) {
	// Load about.
	require_once trailingslashit( get_template_directory() ) . '/inc/theme-info/class-about.php';
	require_once trailingslashit( get_template_directory() ) . '/inc/theme-info/about.php';

	// Load demo.
	require_once trailingslashit( get_template_directory() ) . '/inc/demo/class-demo.php';
	require_once trailingslashit( get_template_directory() ) . '/inc/demo/demo.php';
}
